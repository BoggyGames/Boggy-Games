import { Observable, fromEvent, scan } from 'rxjs';

const firstFetch:string = "https://en.wikipedia.org/api/rest_v1/page/random/summary";
const guessFetch:string = "https://en.wikipedia.org/api/rest_v1/page/summary/";
var target:string = "";
var targetDesc:string = "";
var wordList:string[] = [];
var textnode:HTMLElement;
var button = document.getElementById('guess');
var button2 = document.getElementById('hint');
var button3 = document.getElementById('howto');
var click = fromEvent(button, 'click');
var click2 = fromEvent(button2, 'click');
var click3 = fromEvent(button3, 'click');

function logItem(val:any, count:number) {
    var node = document.createElement("li");
    
    if (val.type == "https://mediawiki.org/wiki/HyperSwitch/errors/not_found") {
        node.innerHTML = "Guess " + count + ": " + (document.getElementById("input") as HTMLInputElement).value + "<br>";
        node.classList.add("lose");
        node.innerHTML += "No article found for " + (document.getElementById("input") as HTMLInputElement).value;
        (document.getElementById("input") as HTMLInputElement).value = "";
        document.getElementById("list").appendChild(node);
        pushMysteryDown();
        return;
    }
    (document.getElementById("input") as HTMLInputElement).value = "";
    node.innerHTML = "Guess " + count + ": " + val.titles.normalized + "<br>";
    displayGuess(node, val.description + " <br> " + val.extract);
    addWords(val.description + " <br> " + val.extract);
    displayWords();
    document.getElementById("list").appendChild(node);
    pushMysteryDown();
    if(val.titles.normalized == target) {
        alert("Congratulations - you have won the summary game in " + count + " guesses!");
        node.classList.add("win");
    }
}

function logHint(count:number) {
    if (count > 5) {
        alert("You have already used all of your hints!");
        return;
    }
    button2.innerHTML = "Hint (" + (5 - count) + " left)";
    var node = document.createElement("li");
    var hintWord:string = "";
    do {
        hintWord = targetDesc.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").split(' ')[Math.floor(Math.random() * targetDesc.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").split(' ').length)];
    }
    while (wordList.includes(hintWord.toLowerCase()));
    node.innerHTML = "Hint " + count + ": <mark>" + hintWord + "</mark>";
    addWords(hintWord);
    displayWords();
    document.getElementById("list").appendChild(node);
    pushMysteryDown();
}

function howToPlay() {
    var node = document.createElement("li");
    node.innerHTML = "How to play: <br>Guess the title of the article from the description. Initially, all of the words of the mystery article will be hidden.<br>If you guess an article different from the goal, all of the words shared between the two descriptions will be revealed in the mystery article's description.<br>Use the hints to reveal a previously hidden word in the title.<br>You can only use 5 hints per game. <br><mark>Good luck and have fun!</mark>";
    document.getElementById("list").appendChild(node);
    pushMysteryDown();
}

function addWords(val:string) {
    val.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").replace(/\s{2,}/g," ").split(' ').forEach(word => {
        if(!wordList.includes(word)) {
            wordList.push(word.toLowerCase());
        }
    });
}

function displayGuess(txt:HTMLElement, val:string) {
    var list:string[] = val.split(' ');
    list.forEach(word => {
        if(targetDesc.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").split(' ').includes(word.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").toLowerCase())) {
            txt.innerHTML += "<mark>" + word + "</mark> ";
        }
        else {
            txt.innerHTML += word + " ";
        }
    });
}

function displayWords() {
    textnode.innerHTML = "Mystery article:\n";
    var list:string[] = targetDesc.split(' ');
    list.forEach(word => {
        if(wordList.includes(word.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").toLowerCase())) {
            textnode.innerHTML += word + " ";
        }
        else {
            textnode.innerHTML += "<mark>???</mark> ";
        }
    });
}

function createGame(val:any) {
    var node = document.createElement("li");
    node.classList.add("game");
    target = val.titles.normalized;
    targetDesc = val.description + " <br> " + val.extract;
    textnode = node;
    displayWords();
    document.getElementById("list").appendChild(node);
}

function pushMysteryDown() {
    var node = textnode;
    document.getElementById("list").removeChild(textnode);
    document.getElementById("list").appendChild(node);
    textnode = node;
}

function getApiData() {
    return new Observable((observer:any) => {
        fetch(firstFetch)
        .then(response => response.json())
        .then(json => {
            observer.next(json);
            observer.complete();
        })
    })
}

function getGuessData() {
    return new Observable((observer:any) => {
        fetch(guessFetch + (document.getElementById("input") as HTMLInputElement).value)
        .then(response => response.json())
        .then(json => {
            observer.next(json);
            observer.complete();
        })
    })
}

getApiData().subscribe(
    (x:any) => createGame(x),
    (error: any) => createGame ('Error: ' + error)
);

click.pipe(scan((guesses:number) => guesses + 1, 0))
.subscribe((guesses:number) => {
    getGuessData().subscribe(
        (x:any) => logItem(x, guesses),
        (error: any) => logItem ('Error: ' + error, guesses)
    );
});

click2.pipe(scan((guesses:number) => guesses + 1, 0))
.subscribe((guesses:number) => {
    logHint(guesses);
});

click3.subscribe(() => {
    howToPlay();
});

fromEvent(document, 'keydown').subscribe((e:any) => {
    if(e.keyCode == 13 && (document.getElementById("input") as HTMLInputElement).value != "") {
        button.click();
    }
});