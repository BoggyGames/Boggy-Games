#pragma once

class CGLRenderer
{
public:
	CGLRenderer(void);
	virtual ~CGLRenderer(void);
		
	bool CreateGLContext(CDC* pDC);			// kreira OpenGL Rendering Context
	UINT LoadTexture(char* fileName);
	void PrepareScene(CDC* pDC);			// inicijalizuje scenu,
	void Reshape(CDC* pDC, int w, int h);	// kod koji treba da se izvrsi svaki put kada se promeni velicina prozora ili pogleda i
	void RotateView(int xAngle, int yAngle);
	void RotatePaddles(int angle);
	void DrawScene(CDC* pDC);				// iscrtava scenu
	void DrawCube(double a);
	void DrawCone(double r, double h, int n);
	void DrawTube(double r1, double r2, double h, int n);
	void DrawPaddle(double length, double width);
	void DestroyScene(CDC* pDC);			// dealocira resurse alocirane u drugim funkcijama ove klase,

	float toRad(float angle);

protected:
	HGLRC	 m_hrc; //OpenGL Rendering Context 

	UINT envTex;
	UINT brickTex;
	int xRotAngle;
	int yRotAngle;
	float pi;
	int paddleRotAngle;
};
