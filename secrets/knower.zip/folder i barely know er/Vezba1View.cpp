
// Vezba1View.cpp : implementation of the CVezba1View class
//
#include "DImage.h"
#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Vezba1.h"
#endif

#include "Vezba1Doc.h"
#include "Vezba1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
#include <iostream>
#include <iostream>
#include <iostream>



// CVezba1View

IMPLEMENT_DYNCREATE(CVezba1View, CView)

BEGIN_MESSAGE_MAP(CVezba1View, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CVezba1View::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_ERASEBKGND()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CVezba1View construction/destruction

CVezba1View::CVezba1View() noexcept
{
	// TODO: add construction code here

	body1.Load((CString)"body1.png");
	arm1.Load((CString)"arm1.png");
	arm2.Load((CString)"arm2.png");
	leg1.Load((CString)"leg1.png");
	leg2.Load((CString)"leg2.png");
	back.Load((CString)"background.jpg");
	ugao0 = 0;
	ugao1 = 0;
	ugao2 = 0;
	ugao3 = 0;
	ugao4 = 0;
	ugao5 = 0;
}

CVezba1View::~CVezba1View()
{
}

BOOL CVezba1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CVezba1View drawing

void CVezba1View::OnDraw(CDC* pDC)
{
	CVezba1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	
	pDC->SetGraphicsMode(GM_ADVANCED);
	CRect rect;
	GetClientRect(&rect);

	CDC* pMemDC = new CDC();
	pMemDC->CreateCompatibleDC(pDC);
	CBitmap bmp;
	bmp.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	pMemDC->SelectObject(&bmp);

	CBrush brush(RGB(200, 220, 255));
	CBrush* pOldBrush = pMemDC->SelectObject(&brush);
	pMemDC->Rectangle(0, 0, rect.Width(), rect.Height());
	pMemDC->SelectObject(pOldBrush);

	pMemDC->SetGraphicsMode(GM_ADVANCED);

	XFORM xform;
	pMemDC->GetWorldTransform(&xform);
	DrawBackground(pMemDC, rect);

	Translate(pMemDC, 250.0, 550.0, false);
	Rotate(pMemDC, -ugao0, false);
	Translate(pMemDC, -250.0, -550.0, false);
	
	DrawTransformer(pMemDC);
	pMemDC->SetWorldTransform(&xform);


	pDC->BitBlt(0, 0, rect.Width(), rect.Height(), pMemDC, 0, 0, SRCCOPY);
	pMemDC->DeleteDC();
	delete pMemDC;
	// TODO: eliminisi flicker
}

void CVezba1View::DrawBackground(CDC* pDC, CRect rc)
{
	CDC* pMemDC = new CDC();
	pMemDC->CreateCompatibleDC(pDC);
	back.Draw(pDC, CRect(0, 0, back.Width(), back.Height()), rc);
	delete pMemDC;
} 
void CVezba1View::DrawArm1(CDC* pDC){
	//obrnuto jer levo
	Translate(pDC, 34.0, 31.0, false);
	Rotate(pDC, -ugao1, false);
	Translate(pDC, -34.0, -31.0, false);
	DrawImgTransparent(pDC, &arm1);
}
void CVezba1View::DrawArm2(CDC* pDC) {
	XFORM xform;
	pDC->GetWorldTransform(&xform);
	Translate(pDC, 178.0, 54.0, false);
	Translate(pDC, 34.0, 31.0, false);
	Rotate(pDC, -ugao1, false);
	Translate(pDC, -34.0, -31.0, false);
	Translate(pDC, 187.0, 41.0, false);
	Translate(pDC, 23.0, 61.0, false);
	Rotate(pDC, 180 + ugao2, false);
	Translate(pDC, -23.0, -61.0, false);
	DrawImgTransparent(pDC, &arm2);
	pDC->SetWorldTransform(&xform);
}
void CVezba1View::DrawLeg1(CDC* pDC) {
	//XFORM xform;
	//pDC->GetWorldTransform(&xform);
	Translate(pDC, 30.0, 125.0, false);
	Rotate(pDC, -ugao3, false);
	Translate(pDC, -30.0, -125.0, false);
	DrawImgTransparent(pDC, &leg1);
	//pDC->SetWorldTransform(&xform);
}
void CVezba1View::DrawLeg2(CDC* pDC) {
	XFORM xform;
	pDC->GetWorldTransform(&xform);
	Translate(pDC, 35.0, 60.0, false);
	Rotate(pDC, ugao4, false);
	Translate(pDC, -35.0, -60.0, false);
	DrawImgTransparent(pDC, &leg2);
	pDC->SetWorldTransform(&xform);
}
void CVezba1View::DrawBody(CDC* pDC) {
	//XFORM xform;
	//pDC->GetWorldTransform(&xform);
	Translate(pDC, 26.0, 133.0, false);
	Rotate(pDC, -ugao5, false);
	Translate(pDC, -26.0, -133.0, false);
	DrawImgTransparent(pDC, &body1);
	//pDC->SetWorldTransform(&xform);
}
void CVezba1View::DrawTransformer(CDC* pDC) {
//napred i nazad transformisu robota. god help me

	Translate(pDC, 200.0, 500.0, false);
	DrawLeg2(pDC);
	Translate(pDC, 5.0, -65.0, false);
	DrawLeg1(pDC);
	Translate(pDC, 212.0, -7.0, false);
	DrawBody(pDC);
	DrawArm2(pDC);
	Translate(pDC, 178.0, 54.0, false);
	DrawArm1(pDC);
}

void CVezba1View::Translate(CDC* pDC, float x, float y, bool rightMultiply)
{
	XFORM forma;
	forma.eDx = x;
	forma.eDy = y;
	forma.eM11 = 1.0;
	forma.eM22 = 1.0;
	forma.eM12 = 0.0;
	forma.eM21 = 0.0;

	pDC->ModifyWorldTransform(&forma, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}

void CVezba1View::Scale(CDC* pDC, float x, float y, bool rightMultiply)
{
	XFORM forma;
	forma.eDx = 0.0;
	forma.eDy = 0.0;
	forma.eM11 = x;
	forma.eM22 = y;
	forma.eM12 = 0.0;
	forma.eM21 = 0.0;

	pDC->ModifyWorldTransform(&forma, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);

}

void CVezba1View::Rotate(CDC* pDC, float angle, bool rightMultiply)
{
	float rad = angle * (3.14 / 180.0) ;
	XFORM forma;
	forma.eDx = 0.0;
	forma.eDy = 0.0;
	forma.eM11 = cos(rad);
	forma.eM12 = sin(rad);
	forma.eM21 = -sin(rad);
	forma.eM22 = cos(rad);

	pDC->ModifyWorldTransform(&forma, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}

void CVezba1View::DrawImgTransparent(CDC* pDC, DImage* pImage) {
	
	XFORM old;

	pDC->GetWorldTransform(&old);
	int w = pImage->Width();
	int h = pImage->Height();

	CBitmap img, mask;
	img.CreateCompatibleBitmap(pDC, w, h);
	mask.CreateBitmap(w, h, 1, 1, NULL);

	CDC* maskDC = new CDC();
	maskDC->CreateCompatibleDC(pDC);
	maskDC->SelectObject(mask);

	CDC* imgDC = new CDC();
	imgDC->CreateCompatibleDC(pDC);
	imgDC->SelectObject(img);

	pImage->Draw(imgDC, CRect(0, 0, w, h), CRect(0, 0, w, h));
	COLORREF bg = imgDC->GetPixel(0, 0);
	imgDC->SetBkColor(bg);

	maskDC->BitBlt(0, 0, w, h, imgDC, 0, 0, SRCCOPY);
	imgDC->SetTextColor(RGB(255, 255, 255));
	imgDC->SetBkColor(RGB(0, 0, 0));
	imgDC->BitBlt(0, 0, w, h, maskDC, 0, 0, SRCAND);
	
	pDC->BitBlt(0, 0, w, h, maskDC, 0, 0, SRCAND);
	pDC->BitBlt(0, 0, w, h, imgDC, 0, 0, SRCPAINT);

	delete maskDC;
	delete imgDC;
	pDC->SetWorldTransform(&old);

}

// CVezba1View printing


void CVezba1View::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CVezba1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CVezba1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CVezba1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CVezba1View::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CVezba1View::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CVezba1View diagnostics

#ifdef _DEBUG
void CVezba1View::AssertValid() const
{
	CView::AssertValid();
}

void CVezba1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CVezba1Doc* CVezba1View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVezba1Doc)));
	return (CVezba1Doc*)m_pDocument;
}
#endif //_DEBUG


// CVezba1View message handlers


BOOL CVezba1View::OnEraseBkgnd(CDC* pDC)
{
	// TODO: Add your message handler code here and/or call default

	return true;
}


void CVezba1View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: Add your message handler code here and/or call default
	if (nChar == 'B')
	{
		ugao0 += 5;
		if (ugao0 > 90) ugao0 = 90;
	}
	else if (nChar == 'N')
	{
		ugao0 -= 5;
		if (ugao0 < 0) ugao0 = 0;
	}
	 if (nChar == 'Q')
	{
		ugao1 += 5;
		if (ugao1 > 270) ugao1 = 270;
}
	else if (nChar == 'A')
	{
		 ugao1 -= 5;
		if (ugao1 < 0) ugao1 = 0;
}
	else if (nChar == 'T')
	 {
		 ugao2 += 10;
		 if (ugao2 > 270) ugao2 = 270;
	 }
	else if (nChar == 'G')
	 {
		 ugao2 -= 10;
		 if (ugao2 < 0) ugao2 = 0;
	 }
	else if (nChar == 'E')
	 {
		 ugao3 += 5;
		 if (ugao3 > 110) ugao3 = 110;
	 }
	else if (nChar == 'D')
	 {
		 ugao3 -= 5;
		 if (ugao3 < 0) ugao3 = 0;
	 }
	else if (nChar == 'R')
	 {
		 ugao4 += 5;
		 if (ugao4 > 110) ugao4 = 110;
	 }
	else if (nChar == 'F')
	 {
		 ugao4 -= 5;
		 if (ugao4 < 0) ugao4 = 0;
	 }
	else if (nChar == 'W')
	 {
		 ugao5 += 5;
		 if (ugao5 > 90) ugao5 = 90;
	 }
	else if (nChar == 'S')
	 {
		 ugao5 -= 5;
		 if (ugao5 < -20) ugao5 = -20;
	 }

	 if (nChar == VK_LEFT)
	 {
		 ugao1 += 15;
		 if (ugao1 > 270) ugao1 = 270;
		 ugao5 -= 1;
		 if (ugao5 < -20) ugao5 = -20;
		 ugao3 += 5;
		 if (ugao3 > 110) ugao3 = 110;
		 ugao4 += 5;
		 if (ugao4 > 110) ugao4 = 110;
		 ugao2 += 15;
		 if (ugao2 > 270) ugao2 = 270;
	 }
	 else if (nChar == VK_RIGHT)
	 {
		 ugao1 -= 15;
		 if (ugao1 < 0) ugao1 = 0;
		 ugao5 += 1;
		 if (ugao5 > 0) ugao5 = 0;
		 ugao3 -= 5;
		 if (ugao3 < 0) ugao3 = 0;
		 ugao4 -= 5;
		 if (ugao4 < 0) ugao4 = 0;
		 ugao2 -= 15;
		 if (ugao2 < 0) ugao2 = 0;
	 }

	 Invalidate();
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}
