str = ""
str2 = ""

with open("flag.txt", 'r') as f:
    str = f.read()

nula = 0
jedan = 1
dva = 2
tri = 3
cetri = 4
pet = 5
sest = 6

# mnogo korisna imena!!

for i in range(len(str)):
    if jedan % 3 == 0:
        str2 += str[len(str)-(i+1)] # ma odmori slobodno
    else:
        str2 += chr(33 + (ord(str[len(str)-(i+1)]) + jedan) % 94)
    dva = jedan + nula
    tri = cetri + sest
    cetri = dva
    nula = jedan
    pet = nula + cetri
    jedan = dva
    sest = jedan

with open("pakao.txt", 'w') as f:
    f.write(str2)